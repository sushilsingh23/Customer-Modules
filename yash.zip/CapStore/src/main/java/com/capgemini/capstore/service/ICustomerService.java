package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Order;

public interface ICustomerService {

	List<Order> placeOrder(Order order);

}