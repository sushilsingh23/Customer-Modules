package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.service.ICustomerService;

@RestController
public class CapStoreController {
	
	@Autowired
	ICustomerService customerService;
	
	@RequestMapping(value = "/placeorder", method = RequestMethod.POST)
	public List<Order> placeOrder(@RequestBody Order order)
	{
		return customerService.placeOrder(order);
	}
	
	
}