package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.dao.CapStoreOrder;


@Service
public class CustomerService implements ICustomerService {
	
	@Autowired
	CapStoreOrder customerOrderDAO;

	@Override
	public List<Order> placeOrder(Order order) {
		
		customerOrderDAO.saveAndFlush(order);
		List<Order> orders = customerOrderDAO.findAll();
		return orders;
		
	}
}