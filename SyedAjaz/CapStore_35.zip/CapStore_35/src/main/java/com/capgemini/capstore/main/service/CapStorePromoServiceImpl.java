package com.capgemini.capstore.main.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Promo;
import com.capgemini.capstore.main.dao.CapStoreOrderDao;
import com.capgemini.capstore.main.dao.CapstorePromoDao;

@Service
public class CapStorePromoServiceImpl implements CapstorePromoService {
	@Autowired
	CapstorePromoDao promoDao;

	@Autowired
	CapStoreOrderDao orderdao;

	@Override
	public Promo search(String promocode) {
		return promoDao.findById(promocode).get();
	}

	@Override
	public Promo promoVal(String promoCode) {
		Promo promo = search(promoCode);
		if (promo != null) {
			LocalDate currentdate = LocalDate.now();

			Instant instant = Instant.ofEpochMilli(promo.getPromoValidity().getTime());
			LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
			LocalDate promolocalDate = localDateTime.toLocalDate();

			if (promolocalDate.compareTo(currentdate) >= 0) {

				return promo;
			} else {
				promo.setSoftDelete("I");
				promoDao.saveAndFlush(promo);

			}
		}
		return promo;
	}

}
