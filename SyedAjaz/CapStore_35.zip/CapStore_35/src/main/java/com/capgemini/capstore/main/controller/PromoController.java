package com.capgemini.capstore.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Promo;
import com.capgemini.capstore.main.service.CapstorePromoService;


@RestController
public class PromoController {
	
	  @Autowired
	  CapstorePromoService promoservice;
	 
	@RequestMapping(value = "/applyPromo/{promoCode}", method = RequestMethod.GET)
	public Promo searchData(@PathVariable String promoCode) {
		
		return promoservice.promoVal(promoCode);
	}
	}
