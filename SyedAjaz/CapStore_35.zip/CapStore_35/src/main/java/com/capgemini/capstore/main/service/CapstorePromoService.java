package com.capgemini.capstore.main.service;

import com.capgemini.capstore.main.beans.Promo;

public interface CapstorePromoService {
	public Promo search(String string);
	public Promo promoVal(String promoCode);
}
