package com.capgemini.capstore.main.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.MerchantFeedback;
import com.capgemini.capstore.main.dao.CapStoreMerchantFeedback;

import ch.qos.logback.core.status.Status;


@Transactional
@Service
public class CapstoreService {

	@Autowired
	private CapStoreMerchantFeedback merchantFeedback;
	
	

	public MerchantFeedback setMerchantFeedback(MerchantFeedback feedback) {
	
		//entityManager.persist(feedback);
		merchantFeedback.save(feedback);

		return feedback;

	}

	
	public List<MerchantFeedback> getFinalMerchantFeedback()
	{
		List<MerchantFeedback> feedback = new ArrayList<MerchantFeedback>();
		feedback = merchantFeedback.findByStatus("R");
		//merchantFeedback.saveAll(feedback);
		return feedback;
	}
		
		
		
}
