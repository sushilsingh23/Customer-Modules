package com.capgemini.capstore.main.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Dummyorder")
@SequenceGenerator(name = "ordseq", initialValue = 9000, allocationSize = 500)
public class DummyOrder {

	@Id
	@Column(name = "orderid")
	@Size(max = 4)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ordseq")
	@NotNull
	private int orderId;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
}
