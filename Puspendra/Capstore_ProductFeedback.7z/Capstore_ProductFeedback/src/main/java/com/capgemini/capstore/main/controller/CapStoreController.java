package com.capgemini.capstore.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.MerchantFeedback;
import com.capgemini.capstore.main.beans.ProductFeedback;
import com.capgemini.capstore.main.service.CapstoreService;

@RestController
public class CapStoreController {
	
	@Autowired
	CapstoreService capstoreService;
	
	
	
	@RequestMapping(value="/get", method = RequestMethod.GET)
	public String getStudent()
	{
		System.out.println("test");
		
		return "new test";
		
	}
	

	@RequestMapping(value="/addMerchantFeedback",method=RequestMethod.POST)
	public MerchantFeedback setProductFeedback(@RequestBody MerchantFeedback merchantFeedBack)
	{
		return capstoreService.setMerchantFeedback(merchantFeedBack);
	}
	
	
	@RequestMapping(value="/getAll",  method = RequestMethod.GET)
	public List<MerchantFeedback> showMerchantFeedback()
	{
		return capstoreService.getFinalMerchantFeedback();
	}
}
