package com.capgemini.capstore.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.beans.ProductFeedback;
import com.capgemini.capstore.main.service.CapstoreService;

@RestController
public class CapStoreController {
	
	@Autowired
	CapstoreService capstoreService;

	@RequestMapping(value="/addFeedback",method=RequestMethod.POST)
	public ProductFeedback setProductFeedback(@RequestBody ProductFeedback productFeedBack)
	{
		return capstoreService.setFeedback(productFeedBack);
	}
	
	@RequestMapping(value="/getFeedback/{customer_Id}", method = RequestMethod.GET)
	public List<ProductFeedback> getProductFeedback(@PathVariable int customer_Id)
	{
		return capstoreService.getProductFeedBack(customer_Id);
	}
	
	@RequestMapping(value="/getAll/{product_Id}",  method = RequestMethod.GET)
	public List<ProductFeedback> showAllProductFeedback(@PathVariable int product_Id)
	{
		return capstoreService.getAll(product_Id);
	}
	@RequestMapping(value="/updateFeeedback/{feedback_Id}", method = RequestMethod.PUT )
	public ProductFeedback updateFeedback(@PathVariable int feedback_Id, @RequestBody ProductFeedback productFeedBack)
	{
		return capstoreService.updateFeedback(feedback_Id, productFeedBack);
	}
	
	
	
	
    // Search Product Module
	
	@RequestMapping(value="/getProductByBrandName/{BrandName}", method = RequestMethod.GET )
	public List<Product> getProductByBrandName(@PathVariable String BrandName)
	{
		return capstoreService.getProductByBrandName(BrandName);
	}
	
	
	@RequestMapping(value="/getProductByCategory/{category}", method = RequestMethod.GET )
	public List<Product> getProductByCategory(@PathVariable String category)
	{
		return capstoreService.getProductByCategory(category);
	}	
	
	
	@RequestMapping(value="/getProductByName/{productName}", method = RequestMethod.GET )
	public List<Product> getProductByName(@PathVariable String productName)
	{
		return capstoreService.getProductByName(productName);
	}
	
	
	
	
	
	
}
