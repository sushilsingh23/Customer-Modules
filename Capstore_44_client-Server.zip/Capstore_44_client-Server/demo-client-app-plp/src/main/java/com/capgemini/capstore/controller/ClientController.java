package com.capgemini.capstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.ResponseCart;
import com.capgemini.capstore.ResponseRemoveItem;

@Controller
public class ClientController {
	
	@GetMapping("/{customerID}")
	public String showCart(@PathVariable int customerID, ModelMap map){

			RestTemplate restTemplate = new RestTemplate(); 
			String url="http://localhost:8829/cart/"+Integer.toString(customerID);
			ResponseCart responseCart = restTemplate.getForObject(url,ResponseCart.class);
			//System.out.println(responseCart);
			map.addAttribute("message",responseCart);
			System.out.println(responseCart);
			return "cart";
			
		}
	
	
	@RequestMapping(value="/remove/{productID}/{customerID}", method=RequestMethod.DELETE)
	public String removeItem( @PathVariable int productID, @PathVariable int customerID, ModelMap model)
	{
		RestTemplate restTemplate=new RestTemplate();
		String url="http://localhost:8829/cart/remove/"+Integer.toString(productID)+Integer.toString(customerID);
		ResponseRemoveItem responseRemoveItem=restTemplate.getForObject(url, ResponseRemoveItem.class);
		model.addAttribute("product",responseRemoveItem);
		
		return "removed";
	}

}
