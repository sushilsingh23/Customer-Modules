package com.capgemini.capstore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.capgemini.capstore")
public class DemoClientAppPlpApplication /* implements CommandLineRunner */ extends SpringBootServletInitializer {

	private static final Logger log = LoggerFactory.getLogger(DemoClientAppPlpApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(DemoClientAppPlpApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(DemoClientAppPlpApplication.class);
	}

	/*
	 * @Override public void run(String... arg0) throws Exception {
	 * 
	 * RestTemplate restTemplate = new RestTemplate(); Response response =
	 * restTemplate.getForObject("http://localhost:8088/api/v1/response",
	 * Response.class); log.info(
	 * "==== RESTful API Response using Spring RESTTemplate START =======");
	 * log.info(response.toString()); log.info(
	 * "==== RESTful API Response using Spring RESTTemplate END =======");
	 * 
	 * }
	 */
}
