package com.capgemini.capstore;

import com.capgemini.capstore.beans.Product;

public class RestResponseRemoveItems {
	
	private Product product;

	public RestResponseRemoveItems() {
		super();
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "RestResponseRemoveItems [product=" + product + "]";
	}
	
	

}
