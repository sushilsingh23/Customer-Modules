package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.CapStoreCart;
import com.capgemini.capstore.dao.CapStoreCustomer;
import com.capgemini.capstore.dao.CapStoreProduct;

@Service
public class CapStoreServiceImpl implements CapStoreService {


	@Autowired
	private CapStoreProduct productDAO;
	@Autowired
	private CapStoreCart cartDAO;
	@Autowired
	private CapStoreCustomer customerDAO;
	
	
	@Override
	public Product removeProduct(int productID, int customerID) {
		
		Product product=productDAO.getOne(productID);
		//Customer customer=customerDAO.getOne(customerID);
		List<Cart> tempCart=cartDAO.findAll();
		for (Cart temp : tempCart) {
			if((temp.getProduct().getProductId()==productID &&temp.getCustomer().getCustomerId()==customerID && temp.getSoftDelete().equals("A")))
			{
				cartDAO.delete(temp);
				return product;
			}
		}
		return null;
	}

	@Override
	public List<Cart> checkout(int customerID) {
		
		List<Cart> tempCart=cartDAO.findAll();
		List<Cart> checkoutCart=new ArrayList<>();
		Customer customer=customerDAO.getOne(customerID);
		for (Cart temp : tempCart) {
			if( temp.getCustomer().getCustomerId()==customer.getCustomerId() && temp.getSoftDelete().equals("A"))
			{
				checkoutCart.add(temp);
			}
		}
		System.out.println(checkoutCart.size());
		return checkoutCart;
	}

	@Override
	public List<Product> showCart(int customerID) {
	
		List<Cart> tempCart=cartDAO.findAll();
		List<Product> productList=new ArrayList<>();
		Customer customer=customerDAO.getOne(customerID);
		for (Cart temp : tempCart) {
			if( temp.getCustomer().getCustomerId()==customer.getCustomerId() && temp.getSoftDelete().equals("A"))
			{
				productList.add(temp.getProduct());
			}
		}
		System.out.println(productList.size());
		return productList;
		//return productDAO.findAll();
	}

}
