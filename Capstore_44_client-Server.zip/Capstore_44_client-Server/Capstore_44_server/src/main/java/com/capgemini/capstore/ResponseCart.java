package com.capgemini.capstore;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseCart {
	
	@JsonProperty
	private RestResponseCart restResponseCart;

	
	public ResponseCart() {
	}
	

	public RestResponseCart getRestResponseCart() {
		return restResponseCart;
	}



	public void setRestResponseCart(RestResponseCart restResponseCart) {
		this.restResponseCart = restResponseCart;
	}



	@Override
	public String toString() {
		return "ResponseCart [restResponseCart=" + restResponseCart + "]";
	}
	
	

}
