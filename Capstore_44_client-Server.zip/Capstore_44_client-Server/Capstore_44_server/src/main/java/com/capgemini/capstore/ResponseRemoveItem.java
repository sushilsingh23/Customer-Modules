package com.capgemini.capstore;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseRemoveItem {
	
	@JsonProperty
	private RestResponseRemoveItems restResponseRemoveItems;

	public ResponseRemoveItem() {
		super();
	}

	public RestResponseRemoveItems getRestResponseRemoveItems() {
		return restResponseRemoveItems;
	}

	public void setRestResponseRemoveItems(RestResponseRemoveItems restResponseRemoveItems) {
		this.restResponseRemoveItems = restResponseRemoveItems;
	}

	@Override
	public String toString() {
		return "ResponseRemoveItem [restResponseRemoveItems=" + restResponseRemoveItems + "]";
	}
	
	
	

}
