package com.capgemini.capstore.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.ResponseCart;
import com.capgemini.capstore.ResponseRemoveItem;
import com.capgemini.capstore.RestResponseCart;
import com.capgemini.capstore.RestResponseRemoveItems;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.service.CapStoreServiceImpl;

@RestController
public class ServerController {
	
	@Autowired
	CapStoreServiceImpl capStoreServiceImpl;
	
	@GetMapping("/")
	public String cartPage(ModelMap model)
	{
		model.addAttribute("cart",capStoreServiceImpl.showCart(201));
		return "cart";
	}
	
	@GetMapping(value="/cart/{customerID}")
	public ResponseCart showCart(@PathVariable int customerID)
	{
		RestResponseCart  restResponseCart=new RestResponseCart();
		
		restResponseCart.setCart(capStoreServiceImpl.showCart(customerID));
		
		ResponseCart responseCart=new ResponseCart();
		responseCart.setRestResponseCart(restResponseCart);
		
		return responseCart ;
	}
	
	@RequestMapping(value="/cart/remove/{productID}/{customerID}", method= {RequestMethod.DELETE, RequestMethod.GET})
	public ResponseRemoveItem removeProduct(@PathVariable int productID, @PathVariable int customerID)
	{
		RestResponseRemoveItems restResponseRemoveItems=new RestResponseRemoveItems();
		restResponseRemoveItems.setProduct(capStoreServiceImpl.removeProduct(productID, customerID));
		
		ResponseRemoveItem responseRemoveItem=new ResponseRemoveItem();
		responseRemoveItem.setRestResponseRemoveItems(restResponseRemoveItems);
		
		return responseRemoveItem;
	}

}
