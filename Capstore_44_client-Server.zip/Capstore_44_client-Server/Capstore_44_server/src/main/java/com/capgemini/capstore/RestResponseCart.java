package com.capgemini.capstore;

import java.util.List;

import com.capgemini.capstore.beans.Product;

public class RestResponseCart {
	
	
	private List<Product> cart;
	
	

	public List<Product> getCart() {
		return cart;
	}

	public void setCart(List<Product> cart) {
		this.cart = cart;
	}

	
	@Override
	public String toString() {
		return "RestResponseCart [cart=" + cart + "]";
	}
}
