package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Product;

public interface CapStoreService {
	
	public Product removeProduct(int productID, int customerID);
	public List<Cart> checkout(int cartID);
	public List<Product> showCart(int customerID);

}
