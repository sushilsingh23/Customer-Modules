package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Address;
import com.capgemini.capstore.beans.Customer;

public interface IShippingDetailService {
	
	public void addAddress(Address address);
	public Customer findCustomer(Integer custId);
	public Address findAll(Integer custId);


}
