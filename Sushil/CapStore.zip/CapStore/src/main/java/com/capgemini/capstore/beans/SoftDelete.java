package com.capgemini.capstore.beans;

public enum SoftDelete {
	Activated, Deactivated
}
