package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Address;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.dao.CapStoreAddress;
import com.capgemini.capstore.dao.CapStoreCustomer;

@Service("shippingService")
public class ShippingDetailServiceImpl implements IShippingDetailService {

	 @Autowired
	    private CapStoreAddress addressDao;
	 @Autowired
		private CapStoreCustomer customerDao;
	@Override
	public void addAddress(Address address) {
		addressDao.save(address);
	}

	@Override
	public Customer findCustomer(Integer custId) {
		Customer customer= customerDao.findById(custId).get();
		if(customer==null) {
			return null;
			
		}
		return customer;
	}

	@Override
	public Address findAll(Integer custId) {
		Customer customer;
		customer=findCustomer(custId);
		if(customer==null) {
			return null;
			
		}
			
		int addressId;
		addressId=customer.getCustomerAddress().getAddressId();
		Address address=addressDao.findById(addressId).get();
		return address;
	}

}
