package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Product;

public interface ISimilarProductService {
	public List<Product> findSimilarProduct(String category);

}
