package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.CapStoreProduct;

@Service
public class SimilarProductService implements ISimilarProductService {

	@Autowired
	private CapStoreProduct productDAO;

	@Override
	public List<Product> findSimilarProduct(String category) {
		/*Product p1 = productDAO.findById(product.getProductId()).get();
		String category = p1.getProductCategory();*/
		List<Product> allProduct = productDAO.findAll();
		List<Product> newProduct = new ArrayList<Product>();
		for (int i = 0; i < allProduct.size(); i++) {
			if (allProduct.get(i).getProductCategory().equals(category)) {
				newProduct.add(allProduct.get(i));
			}

		}

		return newProduct;
	}

}
