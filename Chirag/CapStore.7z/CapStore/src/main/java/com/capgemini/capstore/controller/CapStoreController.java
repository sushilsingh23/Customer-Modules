package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.service.ISimilarProductService;

@RestController
public class CapStoreController {
	@Autowired
	ISimilarProductService similarProductService;
	
	@GetMapping("/getSimilarProducts/{category}")
	public ResponseEntity <List<Product>> getSimilarProducts(@PathVariable ("category")String category){
		List<Product> products= similarProductService.findSimilarProduct(category);
		if (products==null || products.equals(' '))
			 return new ResponseEntity <List<Product>>(HttpStatus.NOT_FOUND);
		 return new ResponseEntity <List<Product>>(products,HttpStatus.OK); 
		
	}
	
	

	
}