package com.capgemini.capstore.main.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.main.beans.Email;

@Repository
public interface CapStoreEmail extends JpaRepository<Email, Integer>{

}
