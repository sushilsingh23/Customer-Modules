package com.capgemini.capstore.main.service;

import java.util.List;

import com.capgemini.capstore.main.beans.Customer;

public interface ICustomerService {

	public void createCustomer(Customer customer);
	public List<Customer> findAllProducts();
	//public Customer getValidCustomer(String emailId, String password);
}
