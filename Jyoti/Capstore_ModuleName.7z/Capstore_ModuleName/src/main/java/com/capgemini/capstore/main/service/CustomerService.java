package com.capgemini.capstore.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.dao.CapStoreCustomer;
import com.capgemini.capstore.main.dao.CapStoreUser;

@Service
public class CustomerService implements ICustomerService{

	

	
	@Autowired
	CapStoreCustomer custRepo;
	
	@Autowired
	CapStoreUser userRepo;

	@Transactional
	public void createCustomer(Customer customer) {
		
		customer.setCustomerAddress(customer.getCustomerAddress());
		customer.setCustomerEmail(customer.getCustomerEmail());
		customer.setCustomerId(customer.getCustomerId());
		customer.setCustomerMobileNumber(customer.getCustomerMobileNumber());
		customer.setCustomerName(customer.getCustomerName());
		customer.setCustomerPincode(customer.getCustomerPincode());
		custRepo.save(customer);
		
	}

	@Transactional
	public List<Customer> findAllProducts() {
		
		List<Customer> list=custRepo.findAll();
		return list;
	}

//	@Override
//	public Customer getValidCustomer(String emailId, String password) {
//		
//		return custRepo.getValidCustomer(emailId, password);
//	}

//	@Override
//	public Optional<User> ValidateLogIn(User user) {
//		if(userRepo.findById(user.getEmailId()) == null) {
//			userRepo.save(user);
//			return userRepo.findById(user.getEmailId());
//		}
//		return null;
//	}

//	@Override
//	public Merchant getMerchant(int merchantId) {
//		return merchantRepo.getOne(merchantId);
//	}
//	
	
	
}
