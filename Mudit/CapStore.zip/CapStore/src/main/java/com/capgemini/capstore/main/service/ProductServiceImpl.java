package com.capgemini.capstore.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.dao.CapStoreProduct;

@Service
public class ProductServiceImpl implements ProductService
{
	@Autowired
	private CapStoreProduct repo;
	
	@Override
	public void createProduct(Product product)
	{		
			repo.save(product);
	}

	@Override
	public Product showProduct(int productId)
	{		
		return repo.findById(productId).get();
	}
}
