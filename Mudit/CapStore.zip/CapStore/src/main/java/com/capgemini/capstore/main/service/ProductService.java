package com.capgemini.capstore.main.service;

import com.capgemini.capstore.main.beans.Product;

public interface ProductService
{
	public void createProduct(Product product);
	public Product showProduct (int productId);
}
