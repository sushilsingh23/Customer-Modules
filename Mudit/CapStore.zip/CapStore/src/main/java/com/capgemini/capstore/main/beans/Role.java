package com.capgemini.capstore.main.beans;

public enum Role {
	Customer,Admin,Merchant
}
