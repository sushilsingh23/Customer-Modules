package com.capgemini.capstore.main.service;

import com.capgemini.capstore.beans.ReturnRequest;

public interface CapstoreMerchantService {
	public double refundMoney(ReturnRequest returnRequest); 
}
