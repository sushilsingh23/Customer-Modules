package com.capgemini.capstore.main.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.ReturnRequest;
import com.capgemini.capstore.main.dao.CapStoreCustomer;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreOrder;
import com.capgemini.capstore.main.dao.CapStoreProduct;
import com.capgemini.capstore.main.dao.CapStoreReturnRequest;

@Service
public class CapstoreCustomerServiceImpl implements CapstoreCustomerService {
	
	@Autowired
	CapStoreReturnRequest capstoreReturnRequest;
	
	@Autowired
	CapStoreCustomer capstoreCustomer;

	@Autowired
	CapStoreProduct capstoreProduct;
	
	@Autowired
	CapStoreMerchant capstoreMerchant;
	
	@Autowired
	CapStoreOrder capstoreOrder;
	
	@Transactional
	@Override
	public ReturnRequest generateReturnRequest(Order order) {
		
		System.out.println(order.getDeliveryStatus());
		System.out.println("I am here");
		ReturnRequest returnRequest = new ReturnRequest();
		if(order.getDeliveryStatus().equals("DELIVERED"))
		{
			
			returnRequest.setReturnStatus("APPLIED");
			returnRequest.setCustomer(capstoreCustomer.findById(order.getCustomer().getCustomerId()).get());
			returnRequest.setMerchant(capstoreMerchant.findById(order.getMerchant().getMerchantId()).get());
//			Order order1 = capstoreOrder.findById(order.getOrder().getOrderId()).get();
			returnRequest.setOrder(capstoreOrder.findById(order.getId()).get());
			returnRequest.setProduct(capstoreProduct.findById(order.getProduct().getProductId()).get());
			returnRequest.setRefundAmount(order.getFinalProductPrice());
			System.out.println(returnRequest.getId());
			System.out.println(returnRequest.getRefundAmount());
			System.out.println(returnRequest.getCustomer());
			System.out.println(returnRequest.getMerchant());
			System.out.println(returnRequest.getOrder());
			System.out.println(returnRequest.getProduct());
			capstoreReturnRequest.save(returnRequest); 
			return returnRequest;
		
		}
		return returnRequest;
	}

	@Override
	public List<Order> findAll() {
		return capstoreOrder.findAll();
	}
}