package com.capgemini.capstore.beans;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Returnrequest")
@SequenceGenerator(name = "retseq", initialValue = 4000, allocationSize = 1000)
public class ReturnRequest {

	@Id
	@Column(name = "retid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "retseq")
	private int id;
	@OneToOne(cascade = CascadeType.ALL)
	@NotNull
	@JoinColumn(name = "customerid")
	private Customer customer;
	@OneToOne(cascade = CascadeType.ALL)
	@NotNull
	@JoinColumn(name = "merchantid")
	private Merchant merchant;
	@OneToOne(cascade = CascadeType.ALL)
	@NotNull
	@JoinColumn(name = "productid")
	private Product product;
	@OneToOne(cascade = CascadeType.ALL)
	@NotNull
	@JoinColumn(name = "orderid")
	private Order order;
	@Column(name = "refundamount")
	@NotNull
	private double refundAmount;
	@Column(name = "returnstatus")
	@NotNull
	@Size(max = 10)
	@Pattern(regexp = "\\b(APPLIED|APPROVED|REJECTED)\\b")
	private String returnStatus;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + id;
		result = prime * result + ((merchant == null) ? 0 : merchant.hashCode());
		result = prime * result + ((order == null) ? 0 : order.hashCode());
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		long temp;
		temp = Double.doubleToLongBits(refundAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((returnStatus == null) ? 0 : returnStatus.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReturnRequest other = (ReturnRequest) obj;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (id != other.id)
			return false;
		if (merchant == null) {
			if (other.merchant != null)
				return false;
		} else if (!merchant.equals(other.merchant))
			return false;
		if (order == null) {
			if (other.order != null)
				return false;
		} else if (!order.equals(other.order))
			return false;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		if (Double.doubleToLongBits(refundAmount) != Double.doubleToLongBits(other.refundAmount))
			return false;
		if (returnStatus == null) {
			if (other.returnStatus != null)
				return false;
		} else if (!returnStatus.equals(other.returnStatus))
			return false;
		return true;
	}

}
