package com.capgemini.capstore.main.service;

import com.capgemini.capstore.beans.ReturnRequest;

public interface CapstoreAdminService {
	public boolean verifyReturnRequest(ReturnRequest returnRequest, boolean status);
}
