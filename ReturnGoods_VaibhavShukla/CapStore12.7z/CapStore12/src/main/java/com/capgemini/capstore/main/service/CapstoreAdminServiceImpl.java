package com.capgemini.capstore.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.ReturnRequest;
import com.capgemini.capstore.main.dao.CapStoreAdmin;
import com.capgemini.capstore.main.dao.CapStoreReturnRequest;

@Service
public class CapstoreAdminServiceImpl implements CapstoreAdminService {

	@Autowired
	CapStoreAdmin CapStoreAdmin;

	@Autowired
	CapStoreReturnRequest capstoreReturnRequest;
	

	@Override
	public boolean verifyReturnRequest(ReturnRequest returnRequest, boolean status) {
		if (returnRequest.getReturnStatus().equals("APPLIED")) {
			if (status == true)
				returnRequest.setReturnStatus("APPROVED");
			else
				returnRequest.setReturnStatus("REJECTED");
			capstoreReturnRequest.save(returnRequest);
			return true;
		} else {
			return false;
		}
	}

}
