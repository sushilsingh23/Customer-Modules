package com.capgemini.capstore.main.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.DummyOrder;
@Repository
public interface CapStoreDummyOrder extends JpaRepository<DummyOrder, Integer>{

}
