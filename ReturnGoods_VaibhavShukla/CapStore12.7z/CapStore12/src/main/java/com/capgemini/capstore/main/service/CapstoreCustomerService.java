package com.capgemini.capstore.main.service;

import java.util.List;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.ReturnRequest;

public interface CapstoreCustomerService {
	public ReturnRequest generateReturnRequest(Order order);
	public List<Order> findAll();
}
