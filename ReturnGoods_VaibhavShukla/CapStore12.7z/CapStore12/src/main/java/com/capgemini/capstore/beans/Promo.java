package com.capgemini.capstore.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Promo")
public class Promo {
	@Id
	@Column(name = "promocode")
	@NotNull
	@Size(max=15)
	private String promoCode;
	@Column(name = "discountoffered")
	@NotNull
	@Size(max =2)
	private double discountOffered;
	@Column(name = "promovalidity")
	@NotNull
	private Date promoValidity;
	@Column(name = "softdelete")
	@NotNull
	@Size(max = 1)
	@Pattern(regexp = "\\b(A|I)\\b")
	private String softDelete;

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public double getDiscountOffered() {
		return discountOffered;
	}

	public void setDiscountOffered(double discountOffered) {
		this.discountOffered = discountOffered;
	}

	public Date getPromoValidity() {
		return promoValidity;
	}

	public void setPromoValidity(Date promoValidity) {
		this.promoValidity = promoValidity;
	}

	public String getSoftDelete() {
		return softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(discountOffered);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((promoCode == null) ? 0 : promoCode.hashCode());
		result = prime * result + ((promoValidity == null) ? 0 : promoValidity.hashCode());
		result = prime * result + ((softDelete == null) ? 0 : softDelete.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Promo other = (Promo) obj;
		if (Double.doubleToLongBits(discountOffered) != Double.doubleToLongBits(other.discountOffered))
			return false;
		if (promoCode == null) {
			if (other.promoCode != null)
				return false;
		} else if (!promoCode.equals(other.promoCode))
			return false;
		if (promoValidity == null) {
			if (other.promoValidity != null)
				return false;
		} else if (!promoValidity.equals(other.promoValidity))
			return false;
		if (softDelete == null) {
			if (other.softDelete != null)
				return false;
		} else if (!softDelete.equals(other.softDelete))
			return false;
		return true;
	}

}
